import HttpError from '@wasp/core/HttpError.js'

export const getPlants = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Plant.findMany({
    where: {
      user: { id: context.user.id }
    }
  })
}

export const getPlant = async ({ plantId }, context) => {
  if (!context.user) {
    throw new HttpError(401);
  }

  const plant = await context.entities.Plant.findUnique({
    where: { id: plantId },
    include: { user: true }
  });

  if (!plant) {
    throw new HttpError(404, `Plant with id ${plantId} not found.`);
  }

  if (plant.user.id !== context.user.id) {
    throw new HttpError(400, `Plant with id ${plantId} does not belong to the user.`);
  }

  return plant;
}