import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAction } from '@wasp/actions';
import createPlant from '@wasp/actions/createPlant';

export function AddPlant() {
  const createPlantFn = useAction(createPlant);
  const [name, setName] = useState('');
  const [wateringFrequency, setWateringFrequency] = useState(0);

  const handleCreatePlant = () => {
    createPlantFn({ name, wateringFrequency });
    setName('');
    setWateringFrequency(0);
  };

  return (
    <div className='p-4'>
      <div className='mb-4'>
        <label className='block text-gray-700 text-sm font-bold mb-2'>Name</label>
        <input
          type='text'
          className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className='mb-4'>
        <label className='block text-gray-700 text-sm font-bold mb-2'>Watering Frequency (in days)</label>
        <input
          type='number'
          className='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
          value={wateringFrequency}
          onChange={(e) => setWateringFrequency(parseInt(e.target.value))}
        />
      </div>
      <button
        onClick={handleCreatePlant}
        className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'
      >
        Create Plant
      </button>
      <Link to='/' className='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-4'>
        Cancel
      </Link>
    </div>
  );
}